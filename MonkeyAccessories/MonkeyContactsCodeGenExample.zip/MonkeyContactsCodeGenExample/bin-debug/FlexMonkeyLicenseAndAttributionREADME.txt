License and Attribution File for FlexMonkey 1.0

Gorilla Logic would like to thank the developers of the following software for their kind permission to use their work in FlexMonkey.

FlexMonkey 1.0, Copyright 2008, 2009 by Gorilla Logic, Inc.
FlexMonkey 1.0 is distributed under the GNU General Public License, v2.

Please see the distribution for a copy of the GNU License.

----------------------------------------------------------
1. The Mate Flex Framework: 

The swc can be downloaded from (Mate_08_8_1.swc) http://mate.asfusion.com/page/downloads
The source is found at http://mate-framework.googlecode.com/svn/trunk/src

Mate is distributed under the Apache 2.0 License: http://www.apache.org/licenses/LICENSE-2.0.html

Here is the copyright for Mate:

Copyright 2008 Nahuel Foronda/AsFusion

Licensed under the Apache License, Version 2.0 (the "License"); 
you may not use this file except in compliance with the License. Y
ou may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0 

Unless required by applicable law or agreed to in writing, s
oftware distributed under the License is distributed on an "AS IS" BASIS, 
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
See the License for the specific language governing permissions and limitations under the License

Author: Nahuel Foronda, Principal Architect
        nahuel at asfusion dot com
                
----------------------------------------------------------
2. GIFPlayer 0.3 from www.bytearray.org (built from source as GIFAnima.swc) http://code.google.com/p/as3gif/

The GIFPlayer is licensed under the GNU General Public License v3: www.gnu.org/licenses/gpl.html
Here is the header from the player source:
/**
* This class lets you play animated GIF files in AS3
* @author Thibault Imbert (bytearray.org)
* @version 0.3
*/

----------------------------------------------------------
3. FlexSpy 1.2:  (FxSpy) http://code.google.com/p/fxspy/

Fxspy is distributed under the New BSD License (http://www.opensource.org/licenses/bsd-license.php)

Here is the copyright notice for the FlexSpy codebase:

    Copyright (c) 2007, Arnaud Pichery [http://coderpeon.ovh.org]
    All rights reserved.
    Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
    Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer 
    in the documentation and/or other materials provided with the distribution.
    Neither the name of the FlexSpy nor the names of its contributors may be used to endorse or promote products derived from this 
    software without specific prior written permission.
    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, 
    BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
    IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
    OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
    OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
    POSSIBILITY OF SUCH DAMAGE.
    
----------------------------------------------------------
4. fluint: http://code.google.com/p/fluint/

fluint is distributed under the MIT License: http://www.opensource.org/licenses/mit-license.php

Here is the copyright notice from DIgital Primates for the Fluint Code Base:
 /**
 * Copyright (c) 2007 Digital Primates IT Consulting Group
 * 
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 * 
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 **/

Gorilla Logic would also like to thank the following Icon and GIF developers.

1. famfamfam.com
2. http://www.laymark.com/